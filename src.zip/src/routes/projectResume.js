/**
 * PROJECT RESUME ROUTES — ENHANCED v3
 * File: src/routes/projectResume.js
 *
 * Two-pass AI analysis:
 *   Pass 1 → Structured ATS data (keywords, scores, section analysis)
 *   Pass 2 → Deep narrative coaching (rewrites, projects to build, career advice)
 *
 * Tools used:
 *   - pdf-parse        → extract text from uploaded PDF
 *   - @anthropic-ai/sdk → Claude API for AI analysis (two calls per analysis)
 *   - multer            → handle multipart file upload
 */

import express from "express";
import multer from "multer";
import Anthropic from "@anthropic-ai/sdk";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";
import { requireAuth } from "../middleware/auth.js";
import Project from "../models/Project.js";

// ─── pdf-parse: CJS package, needs careful ESM handling ──────────────────────
const router = express.Router();

// ─── Multer ───────────────────────────────────────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "application/pdf") cb(null, true);
    else cb(new Error("Only PDF files are accepted"));
  },
});

// ─── Anthropic client ─────────────────────────────────────────────────────────
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

async function extractPdfText(buffer) {
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(buffer),
    useWorkerFetch: false,
    isEvalSupported: false,
    useSystemFonts: true,
  });

  const pdf = await loadingTask.promise;

  try {
    const pageTexts = [];

    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber);
      const textContent = await page.getTextContent();
      const text = textContent.items
        .map((item) => ("str" in item ? item.str : ""))
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();

      if (text) pageTexts.push(text);
      page.cleanup();
    }

    return pageTexts.join("\n").trim();
  } finally {
    await pdf.destroy();
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// AI ANALYSIS — TWO-PASS APPROACH
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * PASS 1: Structured ATS Analysis
 * Extracts: keywords, match score, section scores, strengths, weaknesses
 */
async function runPass1_ATSAnalysis(resumeText, jobDescription) {
  const prompt = `You are a senior ATS (Applicant Tracking System) analyst. You have reviewed thousands of resumes and know exactly how automated screening works.

TASK: Analyze this resume against the job description. Extract structured data.

══════ JOB DESCRIPTION ══════
${jobDescription}

══════ RESUME ══════
${resumeText}

Return ONLY a JSON object (no markdown, no backticks, no extra text):
{
  "matchScore": <integer 0-100>,
  "scoreBreakdown": {
    "keywordMatch": <0-100, what percentage of JD keywords appear in resume>,
    "experienceRelevance": <0-100, how closely does work experience match the role>,
    "formatting": <0-100, is the resume ATS-friendly — no tables, graphics, columns>,
    "completeness": <0-100, are all standard sections present: summary, experience, skills, education, projects>
  },
  "jdKeywords": <array of every important keyword, skill, technology, tool, methodology, soft skill mentioned in the JD — extract at least 15-25 keywords>,
  "jdRequiredSkills": <array of must-have skills from JD>,
  "jdNiceToHave": <array of preferred/bonus skills from JD>,
  "jdSeniority": <"Intern"|"Junior"|"Mid-level"|"Senior"|"Lead"|"Principal">,
  "matchedKeywords": <array of JD keywords found IN the resume>,
  "missingKeywords": <array of JD keywords NOT found in the resume>,
  "sectionScores": [
    {
      "section": <"Contact Information"|"Professional Summary"|"Work Experience"|"Technical Skills"|"Education"|"Projects"|"Certifications"|"Achievements">,
      "score": <0-100>,
      "status": <"excellent"|"good"|"needs_improvement"|"poor"|"missing">,
      "feedback": <2-3 sentences explaining the score FOR THIS SPECIFIC JOB. Reference actual content from the resume. If section is missing, explain why this job needs it.>
    }
    // Include ALL 8 sections above. Mark missing ones with score 0.
  ],
  "resumeStrengths": <array of 5-6 DETAILED strengths. Each must reference specific resume content AND explain why it matters for THIS job. Example: "Your 2 years at XYZ Corp building React dashboards directly maps to the JD's requirement for 'experience with modern frontend frameworks' — this is your strongest selling point.">,
  "resumeWeaknesses": <array of 5-6 DETAILED weaknesses. Each must reference what the JD asks for AND what's missing from the resume. Example: "The JD requires 'experience with CI/CD pipelines and Docker' but your resume mentions no DevOps, containerization, or deployment experience across any of your 3 listed positions.">
}

RULES:
- Extract ALL keywords from the JD — be exhaustive, not just the obvious ones.
- Section feedback must reference ACTUAL content from the resume, not generic advice.
- Strengths and weaknesses must be detailed paragraphs, not one-liners.`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 4096,
    messages: [{ role: "user", content: prompt }],
  });

  const raw = message.content.filter((b) => b.type === "text").map((b) => b.text).join("");
  const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
  return JSON.parse(cleaned);
}

/**
 * PASS 2: Deep Career Coaching
 * Produces: bullet rewrites, projects to build, skills roadmap, coaching narrative
 * Gets Pass 1 results as context so it doesn't repeat work.
 */
async function runPass2_CareerCoaching(resumeText, jobDescription, pass1Results) {
  const prompt = `You are a world-class career coach and resume writer. A candidate has uploaded their resume for a specific job. You already have the ATS analysis results. Now provide DEEP, ACTIONABLE coaching.

══════ JOB DESCRIPTION ══════
${jobDescription}

══════ RESUME ══════
${resumeText}

══════ ATS ANALYSIS ALREADY DONE ══════
Match Score: ${pass1Results.matchScore}%
Missing Keywords: ${(pass1Results.missingKeywords || []).join(", ")}
Key Weaknesses: ${(pass1Results.resumeWeaknesses || []).slice(0, 3).join(" | ")}

══════ YOUR TASK ══════
Now provide the DEEP coaching analysis. Return ONLY a JSON object:

{
  "atsSuggestions": <array of 6-8 SPECIFIC ATS optimization tips. NOT generic advice like "use keywords". Instead: "Your Skills section lists 'JS' — change this to 'JavaScript' because ATS systems often don't recognize abbreviations. Also add 'ES6+' and 'TypeScript' as separate entries since the JD mentions them specifically.">,

  "improvementSuggestions": <array of 8-10 objects, each is a detailed improvement task:
    {
      "section": <which resume section>,
      "priority": <"high"|"medium"|"low">,
      "text": <3-5 sentences of SPECIFIC advice. Tell them EXACTLY what to write. Example: "Your current Summary reads 'Passionate developer looking for opportunities.' This is too generic. Replace it with: 'Full-Stack Developer with 2+ years building React/Node.js applications. Experienced in REST API design, MongoDB, and Agile workflows. Seeking to leverage proven track record of delivering production-ready features at [Company] to drive frontend development at [Target Company].' This mirrors 4 keywords from the JD.">
    }>,

  "bulletRewrites": <array of 4-6 objects. Find ACTUAL weak bullet points from the resume and rewrite them:
    {
      "originalBullet": <exact text from the resume — must be a real bullet point you can find in the resume text>,
      "rewrittenBullet": <your improved version — add metrics, use strong action verbs, incorporate JD keywords. Make it 1-2 lines.>,
      "reason": <1-2 sentences explaining what makes the rewrite better — mention which JD requirements it now addresses>
    }>,

  "skillsToLearn": <array of 5-8 strings. Each should be a specific skill from the JD the candidate lacks, with a brief note on WHY it matters. Example: "Docker & Kubernetes — the JD lists containerization as required, and 78% of similar roles require it. Start with Docker basics, then learn K8s pod management.">,

  "suggestedCertifications": <array of 3-4 strings with FULL certification names. Example: "AWS Certified Cloud Practitioner (Amazon Web Services) — directly relevant since JD mentions AWS cloud infrastructure">,

  "suggestedProjects": <array of 3 objects. These should be portfolio projects the candidate can BUILD to fill gaps in their resume:
    {
      "title": <catchy project name>,
      "description": <3-4 sentences describing what to build, which technologies to use, and what features to include. Be specific enough that the candidate can actually start building.>,
      "skills": <array of skills this project demonstrates — should map to missing JD keywords>,
      "difficulty": <"beginner"|"intermediate"|"advanced">
    }>,

  "careerCoachSummary": <A 6-8 sentence PERSONAL coaching message. Write as if you are sitting across from this person coaching them. Cover:
    1. What is their STRONGEST asset for this role (reference specific resume content)
    2. What is the BIGGEST gap between their resume and the JD
    3. The TOP 3 specific changes that would have the most impact
    4. An honest assessment: are they competitive for this role? What percentage chance do they have?
    5. A motivational but realistic closing — what should they do THIS WEEK to improve their chances
  >
}

CRITICAL RULES:
- bulletRewrites MUST use actual text from the resume — do not invent bullet points.
- suggestedProjects must be specific enough to actually build, not vague ideas.
- careerCoachSummary must feel like a real human coach speaking — warm but honest.
- Every suggestion must explain WHY it matters for THIS specific job.
- Do NOT repeat information from the ATS analysis. Focus on actionable coaching.`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 4096,
    messages: [{ role: "user", content: prompt }],
  });

  const raw = message.content.filter((b) => b.type === "text").map((b) => b.text).join("");
  const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
  return JSON.parse(cleaned);
}

/**
 * Combined analysis: runs both passes and merges results
 */
async function runFullAnalysis(resumeText, jobDescription) {
  console.log("Starting Pass 1: ATS Analysis...");
  const pass1 = await runPass1_ATSAnalysis(resumeText, jobDescription);
  console.log(`Pass 1 complete. Match score: ${pass1.matchScore}%`);

  console.log("Starting Pass 2: Career Coaching...");
  const pass2 = await runPass2_CareerCoaching(resumeText, jobDescription, pass1);
  console.log("Pass 2 complete.");

  // Merge both passes into one insights object
  return {
    // From Pass 1
    resumeMatchScore: pass1.matchScore ?? 0,
    scoreBreakdown: pass1.scoreBreakdown || {},
    jdKeywords: pass1.jdKeywords || [],
    jdRequiredSkills: pass1.jdRequiredSkills || [],
    jdNiceToHave: pass1.jdNiceToHave || [],
    jdSeniority: pass1.jdSeniority || "",
    matchedKeywords: pass1.matchedKeywords || [],
    missingKeywords: pass1.missingKeywords || [],
    sectionScores: pass1.sectionScores || [],
    resumeStrengths: pass1.resumeStrengths || [],
    resumeWeaknesses: pass1.resumeWeaknesses || [],
    // From Pass 2
    atsSuggestions: pass2.atsSuggestions || [],
    improvementSuggestions: pass2.improvementSuggestions || [],
    bulletRewrites: pass2.bulletRewrites || [],
    skillsToLearn: pass2.skillsToLearn || [],
    suggestedCertifications: pass2.suggestedCertifications || [],
    suggestedProjects: pass2.suggestedProjects || [],
    careerCoachSummary: pass2.careerCoachSummary || "",
    // Tracking
    topicWeaknessMap: pass1.missingKeywords || [],
    processingStatus: "done",
    processedAt: new Date(),
  };
}

// ─── Fallback ─────────────────────────────────────────────────────────────────
function buildFallbackInsights(resumeText, jobDescription) {
  const jd = (jobDescription || "").toLowerCase();
  const resume = (resumeText || "").toLowerCase();
  const skills = [
    "react","next.js","node.js","express","mongodb","typescript","javascript",
    "python","java","docker","kubernetes","aws","azure","git","ci/cd",
    "tailwind","css","html","graphql","rest api","postgresql","agile","scrum",
  ];
  const jdKw = skills.filter((s) => jd.includes(s));
  const resKw = skills.filter((s) => resume.includes(s));
  const missing = jdKw.filter((s) => !resKw.includes(s));
  const matched = jdKw.filter((s) => resKw.includes(s));
  const score = jdKw.length === 0 ? 50 : Math.max(10, Math.round((matched.length / jdKw.length) * 100));

  return {
    resumeMatchScore: score,
    scoreBreakdown: { keywordMatch: score, experienceRelevance: 50, formatting: 60, completeness: 50 },
    jdKeywords: jdKw, jdRequiredSkills: jdKw, jdNiceToHave: [], jdSeniority: "Mid-level",
    matchedKeywords: matched, missingKeywords: missing,
    sectionScores: [
      { section: "Professional Summary", score: 30, status: "poor", feedback: "AI was unavailable. Please re-analyze for detailed section feedback." },
    ],
    resumeStrengths: matched.map((s) => `Found "${s}" in your resume`),
    resumeWeaknesses: missing.map((s) => `Missing "${s}" — required by this JD`),
    atsSuggestions: ["Re-analyze when AI is available for detailed ATS suggestions."],
    improvementSuggestions: [{ section: "General", priority: "high", text: "AI analysis was unavailable. Please try re-analyzing your resume." }],
    bulletRewrites: [], skillsToLearn: missing, suggestedCertifications: [], suggestedProjects: [],
    careerCoachSummary: "AI coaching was unavailable for this analysis. Please re-upload your resume to get personalized career advice.",
    topicWeaknessMap: missing, processingStatus: "done", processedAt: new Date(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

// ─── POST /api/projects/:id/resume/upload ─────────────────────────────────────
router.post(
  "/:id/resume/upload",
  requireAuth,
  upload.single("resume"),
  async (req, res) => {
    try {
      const project = await Project.findOne({
        _id: req.params.id,
        userId: req.user.userId,
        status: "active",
      });

      if (!project) return res.status(404).json({ message: "Project not found" });
      if (!req.file) return res.status(400).json({ message: "No PDF file uploaded" });

      // Parse PDF
      let resumeText;
      try {
        resumeText = await extractPdfText(req.file.buffer);
      } catch (err) {
        console.error("PDF parse error:", err.message);
        return res.status(422).json({ message: "Could not read the PDF. Make sure it contains selectable text." });
      }

      if (!resumeText || resumeText.length < 50) {
        return res.status(422).json({ message: "The PDF appears to be empty or scanned (image-only). Please upload a text-based PDF." });
      }

      const jobDescription = (req.body.jdText || project.jobDescription || "").trim();

      // Mark as processing
      project.resumeText = resumeText;
      project.aiInsights = { ...project.aiInsights?.toObject?.() || {}, processingStatus: "processing" };
      await project.save();

      // Run two-pass AI analysis (or fallback)
      let insights;
      try {
        insights = await runFullAnalysis(resumeText, jobDescription);
      } catch (aiErr) {
        console.error("AI analysis failed, using fallback:", aiErr.message);
        insights = buildFallbackInsights(resumeText, jobDescription);
      }

      // Save to project
      project.aiInsights = insights;
      await project.save();

      // Return full analysis
      return res.status(200).json({
        message: "Resume analysed successfully",
        analysis: {
          matchScore: insights.resumeMatchScore,
          scoreBreakdown: insights.scoreBreakdown,
          jdKeywords: insights.jdKeywords,
          jdRequiredSkills: insights.jdRequiredSkills,
          jdNiceToHave: insights.jdNiceToHave,
          jdSeniority: insights.jdSeniority,
          matchedKeywords: insights.matchedKeywords,
          missingKeywords: insights.missingKeywords,
          sectionScores: insights.sectionScores,
          resumeStrengths: insights.resumeStrengths,
          resumeWeaknesses: insights.resumeWeaknesses,
          atsSuggestions: insights.atsSuggestions,
          improvementSuggestions: insights.improvementSuggestions,
          bulletRewrites: insights.bulletRewrites,
          skillsToLearn: insights.skillsToLearn,
          suggestedCertifications: insights.suggestedCertifications,
          suggestedProjects: insights.suggestedProjects,
          careerCoachSummary: insights.careerCoachSummary,
          processingStatus: "done",
          processedAt: insights.processedAt,
        },
        resumeText: project.resumeText,
      });
    } catch (err) {
      console.error("Resume upload error:", err);
      return res.status(500).json({ message: "Server error during resume analysis" });
    }
  }
);

// ─── GET /api/projects/:id/resume/report ──────────────────────────────────────
router.get("/:id/resume/report", requireAuth, async (req, res) => {
  try {
    const project = await Project.findOne({
      _id: req.params.id,
      userId: req.user.userId,
      status: "active",
    });

    if (!project) return res.status(404).json({ message: "Project not found" });

    const i = project.aiInsights || {};

    return res.json({
      hasAnalysis: i.processingStatus === "done",
      processingStatus: i.processingStatus || "pending",
      matchScore: i.resumeMatchScore || 0,
      scoreBreakdown: i.scoreBreakdown || {},
      jdKeywords: i.jdKeywords || [],
      jdRequiredSkills: i.jdRequiredSkills || [],
      jdNiceToHave: i.jdNiceToHave || [],
      jdSeniority: i.jdSeniority || "",
      matchedKeywords: i.matchedKeywords || [],
      missingKeywords: i.missingKeywords || [],
      sectionScores: i.sectionScores || [],
      resumeStrengths: i.resumeStrengths || [],
      resumeWeaknesses: i.resumeWeaknesses || [],
      atsSuggestions: i.atsSuggestions || [],
      improvementSuggestions: i.improvementSuggestions || [],
      bulletRewrites: i.bulletRewrites || [],
      skillsToLearn: i.skillsToLearn || [],
      suggestedCertifications: i.suggestedCertifications || [],
      suggestedProjects: i.suggestedProjects || [],
      careerCoachSummary: i.careerCoachSummary || "",
      suggestions: i.atsSuggestions || [],
      resumeText: project.resumeText || "",
      resumeFileUrl: project.resumeFileUrl || "",
      processedAt: i.processedAt || null,
      jobDescription: project.jobDescription || "",
      jobRole: project.jobRole || "",
      companyName: project.companyName || "",
    });
  } catch (err) {
    console.error("Resume report error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

export default router;
