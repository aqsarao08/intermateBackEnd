/**
 * File: src/routes/projects.js
 *
 * Project CRUD routes.
 * Updated: project creation now accepts multipart/form-data with a resume PDF.
 *          The PDF is parsed server-side and AI analysis runs immediately.
 *          Manual resumeText input has been removed.
 */

import express from "express";
import multer from "multer";
import Anthropic from "@anthropic-ai/sdk";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";
import Project from "../models/Project.js";
import { requireAuth } from "../middleware/auth.js";

// ─── pdf-parse: CJS package with broken ESM interop on Node v24 ───────────────
// We walk every possible nesting to find the actual function.
const router = express.Router();

// ─── Multer: RAM storage for PDF uploads ──────────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are accepted"));
    }
  },
});

// ─── Anthropic client ─────────────────────────────────────────────────────────
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ═══════════════════════════════════════════════════════════════════════════════
// AI ANALYSIS — TWO-PASS APPROACH
// ═══════════════════════════════════════════════════════════════════════════════

async function runPass1_ATSAnalysis(resumeText, jobDescription) {
  const prompt = `You are a senior ATS (Applicant Tracking System) analyst. You have reviewed thousands of resumes and know exactly how automated screening works.

TASK: Analyze this resume against the job description. Extract structured data.

══════ JOB DESCRIPTION ══════
${jobDescription}

══════ RESUME ══════
${resumeText}

Return ONLY a JSON object (no markdown, no backticks, no extra text):
{
  "matchScore": <integer 0-100>,
  "scoreBreakdown": {
    "keywordMatch": <0-100>,
    "experienceRelevance": <0-100>,
    "formatting": <0-100>,
    "completeness": <0-100>
  },
  "jdKeywords": <array of every important keyword, skill, technology, tool, methodology, soft skill mentioned in the JD — extract at least 15-25>,
  "jdRequiredSkills": <array of must-have skills>,
  "jdNiceToHave": <array of preferred skills>,
  "jdSeniority": <"Intern"|"Junior"|"Mid-level"|"Senior"|"Lead"|"Principal">,
  "matchedKeywords": <array of JD keywords found IN the resume>,
  "missingKeywords": <array of JD keywords NOT found in the resume>,
  "sectionScores": [
    {"section": <section name>, "score": <0-100>, "status": <"excellent"|"good"|"needs_improvement"|"poor"|"missing">, "feedback": <2-3 sentences, specific to this job>}
    // Include: Contact Information, Professional Summary, Work Experience, Technical Skills, Education, Projects, Certifications, Achievements
  ],
  "resumeStrengths": <array of 5-6 DETAILED strengths referencing specific resume content AND why it matters for THIS job>,
  "resumeWeaknesses": <array of 5-6 DETAILED weaknesses referencing what the JD asks vs what's missing>
}`;

  const msg = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514", max_tokens: 4096,
    messages: [{ role: "user", content: prompt }],
  });
  const raw = msg.content.filter((b) => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim());
}

async function runPass2_CareerCoaching(resumeText, jobDescription, pass1) {
  const prompt = `You are a world-class career coach and resume writer. Provide DEEP, ACTIONABLE coaching.

══════ JOB DESCRIPTION ══════
${jobDescription}

══════ RESUME ══════
${resumeText}

══════ ATS RESULTS ══════
Match Score: ${pass1.matchScore}% | Missing: ${(pass1.missingKeywords || []).join(", ")}

Return ONLY JSON:
{
  "atsSuggestions": <6-8 SPECIFIC ATS tips — not generic, reference actual resume content>,
  "improvementSuggestions": <8-10 objects: {"section","priority","text"} — text should be 3-5 sentences with EXACT rewording examples>,
  "bulletRewrites": <4-6 objects: {"originalBullet","rewrittenBullet","reason"} — use ACTUAL bullets from the resume>,
  "skillsToLearn": <5-8 skills with brief WHY for each>,
  "suggestedCertifications": <3-4 with full names and relevance>,
  "suggestedProjects": <3 objects: {"title","description","skills","difficulty"} — specific enough to start building>,
  "careerCoachSummary": <6-8 sentences of personal coaching — strongest asset, biggest gap, top 3 changes, honest chance assessment, what to do this week>
}`;

  const msg = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514", max_tokens: 4096,
    messages: [{ role: "user", content: prompt }],
  });
  const raw = msg.content.filter((b) => b.type === "text").map((b) => b.text).join("");
  return JSON.parse(raw.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim());
}

async function runAnalysis(resumeText, jobDescription) {
  try {
    console.log("Starting Pass 1: ATS Analysis...");
    const p1 = await runPass1_ATSAnalysis(resumeText, jobDescription);
    console.log(`Pass 1 done. Score: ${p1.matchScore}%`);

    console.log("Starting Pass 2: Career Coaching...");
    const p2 = await runPass2_CareerCoaching(resumeText, jobDescription, p1);
    console.log("Pass 2 done.");

    return {
      resumeMatchScore: p1.matchScore ?? 0,
      scoreBreakdown: p1.scoreBreakdown || {},
      jdKeywords: p1.jdKeywords || [], jdRequiredSkills: p1.jdRequiredSkills || [],
      jdNiceToHave: p1.jdNiceToHave || [], jdSeniority: p1.jdSeniority || "",
      matchedKeywords: p1.matchedKeywords || [], missingKeywords: p1.missingKeywords || [],
      sectionScores: p1.sectionScores || [],
      resumeStrengths: p1.resumeStrengths || [], resumeWeaknesses: p1.resumeWeaknesses || [],
      topicWeaknessMap: p1.missingKeywords || [],
      atsSuggestions: p2.atsSuggestions || [],
      improvementSuggestions: p2.improvementSuggestions || [],
      bulletRewrites: p2.bulletRewrites || [],
      skillsToLearn: p2.skillsToLearn || [],
      suggestedCertifications: p2.suggestedCertifications || [],
      suggestedProjects: p2.suggestedProjects || [],
      careerCoachSummary: p2.careerCoachSummary || "",
      processingStatus: "done", processedAt: new Date(),
    };
  } catch (err) {
    console.error("AI analysis error, using fallback:", err.message);
    return buildFallbackInsights(resumeText, jobDescription);
  }
}

function buildFallbackInsights(resumeText, jobDescription) {
  const jd = (jobDescription || "").toLowerCase();
  const resume = (resumeText || "").toLowerCase();
  const skills = ["react","next.js","node.js","express","mongodb","typescript","javascript","python","java","docker","kubernetes","aws","azure","git","ci/cd","tailwind","css","html","graphql","rest api","postgresql","agile","scrum"];
  const jdKw = skills.filter((s) => jd.includes(s));
  const resKw = skills.filter((s) => resume.includes(s));
  const missing = jdKw.filter((s) => !resKw.includes(s));
  const matched = jdKw.filter((s) => resKw.includes(s));
  const score = jdKw.length === 0 ? 50 : Math.max(10, Math.round((matched.length / jdKw.length) * 100));
  return {
    resumeMatchScore: score,
    scoreBreakdown: { keywordMatch: score, experienceRelevance: 50, formatting: 60, completeness: 50 },
    jdKeywords: jdKw, jdRequiredSkills: jdKw, jdNiceToHave: [], jdSeniority: "Mid-level",
    matchedKeywords: matched, missingKeywords: missing,
    sectionScores: [{ section: "General", score: 50, status: "needs_improvement", feedback: "AI unavailable. Re-analyze for detailed feedback." }],
    resumeStrengths: matched.map((s) => `Found "${s}" in your resume`),
    resumeWeaknesses: missing.map((s) => `Missing "${s}" — required by this JD`),
    atsSuggestions: ["Re-analyze when AI is available."],
    improvementSuggestions: [{ section: "General", priority: "high", text: "AI was unavailable. Please try again." }],
    bulletRewrites: [], skillsToLearn: missing, suggestedCertifications: [], suggestedProjects: [],
    careerCoachSummary: "AI coaching was unavailable. Please re-upload to get personalized advice.",
    topicWeaknessMap: missing, processingStatus: "done", processedAt: new Date(),
  };
}

// ─── Serializer ───────────────────────────────────────────────────────────────
async function extractPdfText(buffer) {
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(buffer),
    useWorkerFetch: false,
    isEvalSupported: false,
    useSystemFonts: true,
  });

  const pdf = await loadingTask.promise;

  try {
    const pageTexts = [];

    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber);
      const textContent = await page.getTextContent();
      const text = textContent.items
        .map((item) => ("str" in item ? item.str : ""))
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();

      if (text) pageTexts.push(text);
      page.cleanup();
    }

    return pageTexts.join("\n").trim();
  } finally {
    await pdf.destroy();
  }
}

function buildProject(project) {
  return {
    id: project._id.toString(),
    title: project.title,
    companyName: project.companyName,
    jobRole: project.jobRole,
    jobDescription: project.jobDescription,
    resumeFileUrl: project.resumeFileUrl || "",
    resumeText: project.resumeText,
    aiInsights: project.aiInsights || {},
    outcome: project.outcome || {},
    status: project.status,
    createdAt: project.createdAt,
    updatedAt: project.updatedAt,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

// GET all user projects
router.get("/", requireAuth, async (req, res) => {
  try {
    const projects = await Project.find({
      userId: req.user.userId,
      status: "active",
    }).sort({ updatedAt: -1 });

    return res.status(200).json(projects.map(buildProject));
  } catch (error) {
    console.error("Get projects error:", error);
    return res.status(500).json({ message: "Server error while getting projects" });
  }
});

// GET one project
router.get("/:id", requireAuth, async (req, res) => {
  try {
    const project = await Project.findOne({
      _id: req.params.id,
      userId: req.user.userId,
      status: "active",
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    return res.status(200).json(buildProject(project));
  } catch (error) {
    console.error("Get project error:", error);
    return res.status(500).json({ message: "Server error while getting project" });
  }
});

// ─── CREATE project (multipart/form-data with resume PDF) ─────────────────────
// Text fields: title, companyName, jobRole, jobDescription
// File field:  resume (PDF, required)
router.post("/", requireAuth, upload.single("resume"), async (req, res) => {
  try {
    const {
      title,
      companyName = "",
      jobRole = "",
      jobDescription = "",
    } = req.body;

    const cleanTitle = String(title || "").trim();
    if (!cleanTitle) {
      return res.status(400).json({ message: "Project title is required" });
    }

    const cleanJD = String(jobDescription || "").trim();
    if (!cleanJD) {
      return res.status(400).json({ message: "Job description is required" });
    }

    // ── Require resume PDF ──
    if (!req.file) {
      return res.status(400).json({ message: "Resume PDF is required" });
    }

    // ── Parse PDF ──
    let resumeText = "";
    try {
      console.log("PDF upload received:", {
        fieldname: req.file.fieldname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        bufferLength: req.file.buffer?.length,
        pdfParseType: typeof pdfjsLib.getDocument,
      });
      resumeText = await extractPdfText(req.file.buffer);
    } catch (pdfErr) {
      console.error("PDF parse error:", pdfErr.message, pdfErr.stack);
      return res.status(422).json({
        message: "Could not read the PDF. Make sure it contains selectable text.",
      });
    }

    if (!resumeText || resumeText.length < 50) {
      return res.status(422).json({
        message: "The PDF appears to be empty or scanned (image-only). Please upload a text-based PDF.",
      });
    }

    // ── Run AI analysis ──
    const aiInsights = await runAnalysis(resumeText, cleanJD);

    const project = await Project.create({
      userId: req.user.userId,
      title: cleanTitle,
      companyName: String(companyName || "").trim(),
      jobRole: String(jobRole || "").trim(),
      jobDescription: cleanJD,
      resumeText,
      resumeFileUrl: "",
      aiInsights,
      outcome: {
        status: "applied",
        notes: "",
        updatedAt: new Date(),
      },
    });

    return res.status(201).json({
      message: "Project created successfully",
      project: buildProject(project),
    });
  } catch (error) {
    console.error("Create project error:", error);
    return res.status(500).json({ message: "Server error while creating project" });
  }
});

// ─── UPDATE project (multipart — supports optional re-upload of resume PDF) ───
router.put("/:id", requireAuth, upload.single("resume"), async (req, res) => {
  try {
    const current = await Project.findOne({
      _id: req.params.id,
      userId: req.user.userId,
    });

    if (!current) {
      return res.status(404).json({ message: "Project not found" });
    }

    const update = {};
    if (typeof req.body.title === "string") update.title = req.body.title.trim();
    if (typeof req.body.companyName === "string") update.companyName = req.body.companyName.trim();
    if (typeof req.body.jobRole === "string") update.jobRole = req.body.jobRole.trim();
    if (typeof req.body.jobDescription === "string") update.jobDescription = req.body.jobDescription.trim();
    if (typeof req.body.status === "string") update.status = req.body.status;

    // ── Parse new resume PDF if provided ──
    let newResumeText = null;
    if (req.file) {
      try {
        console.log("PDF re-upload received:", {
          fieldname: req.file.fieldname,
          mimetype: req.file.mimetype,
          size: req.file.size,
          bufferLength: req.file.buffer?.length,
        });
        newResumeText = await extractPdfText(req.file.buffer);
      } catch (pdfErr) {
        console.error("PDF parse error (update):", pdfErr.message, pdfErr.stack);
        return res.status(422).json({
          message: "Could not read the PDF. Make sure it contains selectable text.",
        });
      }

      if (!newResumeText || newResumeText.length < 50) {
        return res.status(422).json({
          message: "The PDF appears to be empty or scanned. Please upload a text-based PDF.",
        });
      }

      update.resumeText = newResumeText;
    }

    // ── Re-run analysis if we have resume text ──
    const finalResumeText = newResumeText || current.resumeText || "";
    const finalJD = (update.jobDescription !== undefined ? update.jobDescription : current.jobDescription) || "";

    if (finalResumeText) {
      update.aiInsights = await runAnalysis(finalResumeText, finalJD);
    }

    const project = await Project.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      { $set: update },
      { new: true }
    );

    return res.status(200).json({
      message: "Project updated successfully",
      project: buildProject(project),
    });
  } catch (error) {
    console.error("Update project error:", error);
    return res.status(500).json({ message: "Server error while updating project" });
  }
});

// REPROCESS AI
router.post("/:id/process", requireAuth, async (req, res) => {
  try {
    const project = await Project.findOne({
      _id: req.params.id,
      userId: req.user.userId,
      status: "active",
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (!project.resumeText) {
      return res.status(400).json({ message: "No resume text available. Upload a resume PDF first." });
    }

    project.aiInsights = await runAnalysis(project.resumeText, project.jobDescription || "");
    await project.save();

    return res.status(200).json({
      message: "Project processed successfully",
      project: buildProject(project),
    });
  } catch (error) {
    console.error("Process project error:", error);
    return res.status(500).json({ message: "Server error while processing project" });
  }
});

// GET processing status
router.get("/:id/status", requireAuth, async (req, res) => {
  try {
    const project = await Project.findOne({
      _id: req.params.id,
      userId: req.user.userId,
      status: "active",
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    return res.status(200).json({
      processingStatus: project.aiInsights?.processingStatus || "pending",
      processedAt: project.aiInsights?.processedAt || null,
    });
  } catch (error) {
    console.error("Get project status error:", error);
    return res.status(500).json({ message: "Server error while getting project status" });
  }
});

// UPDATE outcome
router.patch("/:id/outcome", requireAuth, async (req, res) => {
  try {
    const { status, notes = "" } = req.body;

    const allowedStatuses = [
      "applied", "interviewing", "offer", "rejected", "accepted", "withdrawn",
    ];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ message: "Invalid outcome status" });
    }

    const project = await Project.findOneAndUpdate(
      {
        _id: req.params.id,
        userId: req.user.userId,
        status: "active",
      },
      {
        $set: {
          outcome: {
            status,
            notes: String(notes || "").trim(),
            updatedAt: new Date(),
          },
        },
      },
      { new: true }
    );

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    return res.status(200).json({
      message: "Outcome updated successfully",
      project: buildProject(project),
    });
  } catch (error) {
    console.error("Update outcome error:", error);
    return res.status(500).json({ message: "Server error while updating outcome" });
  }
});

// ARCHIVE project
router.delete("/:id", requireAuth, async (req, res) => {
  try {
    const project = await Project.findOneAndUpdate(
      {
        _id: req.params.id,
        userId: req.user.userId,
      },
      { $set: { status: "archived" } },
      { new: true }
    );

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    return res.status(200).json({ message: "Project archived successfully" });
  } catch (error) {
    console.error("Delete project error:", error);
    return res.status(500).json({ message: "Server error while deleting project" });
  }
});

export default router;
