import FormData from "form-data";

const ANALYZER_URL = process.env.RESUME_ANALYZER_URL || "http://localhost:8001";

function normalizeAnalysis(payload = {}) {
  return {
    matchScore: payload.match_score ?? payload.matchScore ?? 0,
    jdKeywords: payload.jd_keywords ?? payload.jdKeywords ?? [],
    jdRequiredSkills: payload.jd_required_skills ?? payload.jdRequiredSkills ?? [],
    jdNiceToHave: payload.jd_nice_to_have ?? payload.jdNiceToHave ?? [],
    jdSeniority: payload.jd_seniority ?? payload.jdSeniority ?? "Not specified",
    missingKeywords: payload.missing_keywords ?? payload.missingKeywords ?? [],
    resumeStrengths: payload.resume_strengths ?? payload.resumeStrengths ?? [],
    resumeWeaknesses: payload.resume_weaknesses ?? payload.resumeWeaknesses ?? [],
    atsSuggestions: payload.ats_suggestions ?? payload.atsSuggestions ?? [],
    improvementSuggestions: payload.improvement_suggestions ?? payload.improvementSuggestions ?? [],
    resumeText: payload.resume_text ?? payload.resumeText ?? "",
    jobDescriptionText: payload.jd_text ?? payload.jobDescriptionText ?? "",
  };
}

export async function analyzeDocuments({ resumeFile, jdFile, jdText }) {
  const form = new FormData();

  form.append("resume_file", resumeFile.buffer, {
    filename: resumeFile.originalname,
    contentType: resumeFile.mimetype,
  });

  if (jdFile) {
    form.append("jd_file", jdFile.buffer, {
      filename: jdFile.originalname,
      contentType: jdFile.mimetype,
    });
  }

  if (jdText?.trim()) {
    form.append("jd_text", jdText.trim());
  }

  const response = await fetch(`${ANALYZER_URL}/analyze`, {
    method: "POST",
    headers: form.getHeaders(),
    body: form,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || data.message || "Resume analyzer service failed");
  }

  return normalizeAnalysis(data);
}
